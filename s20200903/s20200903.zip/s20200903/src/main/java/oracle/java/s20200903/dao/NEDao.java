package oracle.java.s20200903.dao;

public interface NEDao {

}
