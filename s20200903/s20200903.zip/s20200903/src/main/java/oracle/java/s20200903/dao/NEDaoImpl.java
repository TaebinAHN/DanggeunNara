package oracle.java.s20200903.dao;

public class NEDaoImpl implements NEDao {

}
