package oracle.java.s20200903.model;

public class NEPost {

}
