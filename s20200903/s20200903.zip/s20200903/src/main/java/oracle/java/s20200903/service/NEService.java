package oracle.java.s20200903.service;

public interface NEService {

}
